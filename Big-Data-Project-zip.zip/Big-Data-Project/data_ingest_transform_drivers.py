""" data_ingest_transform.py is a Dataflow pipeline which reads a file and writes
its contents to a BigQuery table.

We read a json schema of the intended output into BigQuery,
and transforms the 'date' data to match the format BigQuery expects 'YYYY-MM-DD'.
"""


import argparse
import csv
import logging
import os
import datetime

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io.gcp.bigquery_tools import parse_table_schema_from_json


class DataTransformation:
    """A helper class which contains the logic to translate the file into a
  format BigQuery will accept."""

    def __init__(self):
        dir_path = os.path.dirname(os.path.realpath(__file__))
        self.schema_str = ''

        # Here we read the output schema from a json file.  This is used to specify the types
        # of data we are writing to BigQuery.

        schema_file = os.path.join(dir_path, 'resources', 'drivers.json')
        with open(schema_file) \
                as f:
            data = f.read()
            # Wrapping the schema in fields is required for the BigQuery API.
            self.schema_str = '{"fields": ' + data + '}'

    def parse_method(self, string_input):

        """This method translates a single line of comma separated values to a
        dictionary which can be loaded into BigQuery.

        Args:
            string_input: A comma separated list of values in the form of

        Returns:
            A dict mapping BigQuery column names as keys to the corresponding value
            parsed from string_input.

                example output:
                      {'Key': 'Value',
                       'Key': 'Value',
                       'Key': 'Value',
                       'Key': 'Value',
                       'Key': 'Value',
                       }
        """
        # We Strip out return characters and quote characters.
        schema = parse_table_schema_from_json(self.schema_str)

        field_map = [f for f in schema.fields]

        # We Use a CSV Reader which can handle quoted strings etc.
        reader = csv.reader(string_input.split('\n'))

        for csv_row in reader:
            row = {}
            i = 0
            # Iterate over the values from our csv file, applying any transformation logic.
            for value in csv_row:
                # If the schema indicates this field is a date format, we must
                # transform the date from the source data into a format that
                # BigQuery can understand.
                if field_map[i].type == 'DATE':
                    d = datetime.datetime.strptime(value, "%m/%d/%Y")
                    # Format the date to YYYY-MM-DD format which BigQuery
                    # accepts.
                    value = '-'.join((str(d.year),str(d.month), str(d.day)))

                row[field_map[i].name] = value
                i += 1

            return row


def run(argv=None):
    """The main function which creates the pipeline and runs it."""
    parser = argparse.ArgumentParser()

    parser.add_argument(
        '--input', 
        dest='input', 
        required=False,
        help='Input file to read.  This can be a local file or '
             'a file in a Google Storage Bucket.',
        default='gs://total-ensign-370100/data_files/drivers.csv')
    # This defaults to the temp dataset in your BigQuery project.

    parser.add_argument(
        '--output', 
        dest='output', 
        required=False,
        help='Output BQ table to write results to.',
        default='lake.drivers')

    # Parse arguments from the command line.
    known_args, pipeline_args = parser.parse_known_args(argv)

    data_ingestion = DataTransformation()

    # Initiate the pipeline using the pipeline arguments passed in from the
    # command line. 
    p = beam.Pipeline(options=PipelineOptions(pipeline_args))
    schema = parse_table_schema_from_json(data_ingestion.schema_str)

    (p
    # Read the file. The pipeline originates here. Lines read from the file are the 
    # first thing that is processed after. We make advantage of the command line's 
    # input argument. The header row on the first line is likewise skipped.
     | 'Read From Text' >> beam.io.ReadFromText(known_args.input,
                                                skip_header_lines=1)
    # A single row of data from a CSV file is converted at this level of the 
    # pipeline into a dictionary object that BigQuery can use.
    # It makes reference to a function that we created. This activity will simultaneously
    # on several workers with input from the pipeline's preceding stage.
     | 'String to BigQuery Row' >> beam.Map(lambda s:
                                            data_ingestion.parse_method(s))
     | 'Write to BigQuery' >> beam.io.Write(
        beam.io.BigQuerySink(
            # The table name is a required argument for the BigQuery sink.
            # In this case we use the value passed in from the command line.
            known_args.output,
            # Here we use the JSON schema read in from a JSON file.
            schema=schema,
            # Creates the table in BigQuery if it does not yet exist.
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            # Deletes all data in the BigQuery table before writing.
            write_disposition=beam.io.BigQueryDisposition.WRITE_TRUNCATE)))
    p.run().wait_until_finish()


if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run()
